import { useState, useEffect, useRef } from "react";

// ── Brand tokens ──────────────────────────────────────────────────────────────
const NAVY = "#1F2D3D";
const GOLD = "#C5A25D";
const GOLD_DIM = "#8a6e3e";

// ── Data ──────────────────────────────────────────────────────────────────────
const CATEGORIES = ["All", "Infrastructure", "Automations", "AI Systems", "Revenue Systems", "Clinical Tools", "Reactivation"];

const INITIAL_PROJECTS = [
  // ── DONE ──
  { id: 1,  status: "done",     title: "System Audit & Stabilization",          category: "Infrastructure",    priority: "high",   owner: "Ella",            kpi: "0 broken automations",         nextAction: "Ongoing maintenance",            blocker: "",                        notes: "Full audit of hub + all sub-accounts. Named conventions, folder structure standardized.", archived: false },
  { id: 2,  status: "done",     title: "Day 1 & Day 2 Reminder Sequences",      category: "Automations",       priority: "high",   owner: "Ella",            kpi: "85%+ show rate",               nextAction: "Monitor show rate weekly",       blocker: "",                        notes: "Rebuilt with conditional safeguards. 48hr / 24hr / 3hr / 1hr cadence.", archived: false },
  { id: 3,  status: "done",     title: "Appointment Origin Tracking",           category: "Infrastructure",    priority: "medium", owner: "Ella",            kpi: "100% attribution accuracy",    nextAction: "Validate across all locations",  blocker: "",                        notes: "Hub ↔ Satellite logic. Tracks booking source cross-location.", archived: false },
  { id: 4,  status: "done",     title: "NPC Engagement Reporting Workflow",     category: "Automations",       priority: "medium", owner: "Ella",            kpi: "Video completion tracked",     nextAction: "Review monthly engagement data", blocker: "",                        notes: "Pre-appointment video completion tracking. Launched and operational.", archived: false },
  { id: 5,  status: "done",     title: "Treatment Plan Page (Custom-Coded)",    category: "Revenue Systems",   priority: "high",   owner: "Ella",            kpi: "Care plan acceptance rate",    nextAction: "Build downstream automations",   blocker: "",                        notes: "GHL hybrid. 180+ supplement custom fields. Webhooks remapped. Killer Switch built.", archived: false },
  { id: 6,  status: "done",     title: "Booking SOP + GHL Training",            category: "Infrastructure",    priority: "medium", owner: "Ella",            kpi: "Staff trained all locations",  nextAction: "Refresh after snapshot ships",   blocker: "",                        notes: "Delivered to staff. Sub-accounts standardized.", archived: false },
  { id: 7,  status: "done",     title: "Day 2 ROF Kiosk System",               category: "AI Systems",        priority: "high",   owner: "Ella + Christian",kpi: "Coaching reports generated",  nextAction: "Monitor Airtable + Slack output","blocker": "",                      notes: "Full stack: GHL funnel, Deepgram audio, Claude API grading (6 cats), Airtable, Make → Slack #clinical-coaching.", archived: false },
  { id: 8,  status: "done",     title: "Progress / Re-Exam System (PE1–PE3)",   category: "Clinical Tools",    priority: "high",   owner: "Ella",            kpi: "Approved by Averi + Dr. Dave", nextAction: "Deploy to all locations",        blocker: "",                        notes: "3 files built + debugged. pdf-lib merge. CA Routing Form built. Approved.", archived: false },
  { id: 9,  status: "done",     title: "WAC Project Hub",                       category: "Infrastructure",    priority: "medium", owner: "Ella",            kpi: "Live on Vercel",               nextAction: "Maintain & iterate",             blocker: "",                        notes: "React + Vite. Tiered access. Kanban + list views. Archive feature.", archived: false },
  { id: 10, status: "done",     title: "Birthday Reactivation (TrackStat)",     category: "Reactivation",      priority: "medium", owner: "Ella",            kpi: "Running each week",            nextAction: "Migrate to GHL natively",        blocker: "",                        notes: "Ella took ownership. Trained by Angel on TrackStat.", archived: false },
  { id: 11, status: "done",     title: "Lead Routing Automations",              category: "Automations",       priority: "high",   owner: "Ella",            kpi: "Zero missed cross-loc leads",  nextAction: "Monitor + QA quarterly",         blocker: "",                        notes: "Cross-location lead routing between sub-accounts.", archived: false },

  // ── IN PROGRESS ──
  { id: 12, status: "active",   title: "GHL Snapshot Cleanup & Finalization",   category: "Infrastructure",    priority: "high",   owner: "Ella",            kpi: "Snapshot locked + deployable", nextAction: "Finalize hub + satellite split", blocker: "Architecture alignment",  notes: "System clean + deployment-ready. Snapshot not yet locked due to architecture shifts.", archived: false },
  { id: 13, status: "active",   title: "Event Registration System",             category: "Automations",       priority: "medium", owner: "Ella",            kpi: "Replace SignUpGenius 100%",     nextAction: "Resolve event date injection Q", blocker: "Open Q: hidden field vs hardcoded", notes: "Project brief produced. Key Q: how event date populates into GHL.", archived: false },

  // ── BACKLOG ──
  { id: 14, status: "backlog",  title: "Treatment Plan Downstream Automations", category: "Revenue Systems",   priority: "high",   owner: "Ella",            kpi: "Zero manual post-sign steps",  nextAction: "Map post-signature workflow",    blocker: "",                        notes: "Post-signature: scheduling, finance copy, patient PDF delivery.", archived: false },
  { id: 15, status: "backlog",  title: "PI Automation Revamp",                  category: "Automations",       priority: "low",    owner: "Ella",            kpi: "PI pipeline fully automated",  nextAction: "Review Shari transcript notes",  blocker: "",                        notes: "Personal injury pipeline rebuild. Low priority.", archived: false },
  { id: 16, status: "backlog",  title: "Reactivation Engine (GHL-Native)",      category: "Reactivation",      priority: "high",   owner: "Ella",            kpi: "3–5% reactivation/month",      nextAction: "Import EHR databases per loc",   blocker: "EHR data import",         notes: "Segments: 90-day, 6-month, 12-month, PI past, corrective grads.", archived: false },
  { id: 17, status: "backlog",  title: "Review Generation Automation",          category: "Automations",       priority: "medium", owner: "Ella",            kpi: "10+ Google reviews/clinic/mo", nextAction: "Define trigger events",          blocker: "",                        notes: "Triggers: after ROF, 10th visit, graduation. Unhappy patient safeguard.", archived: false },
  { id: 18, status: "backlog",  title: "Website AI Chatbot",                    category: "AI Systems",        priority: "medium", owner: "Ella + Joanna",   kpi: "Leads captured 24/7",          nextAction: "Draft FAQ training data",        blocker: "",                        notes: "GHL-native chatbot. FAQ + script training. Always-on lead capture.", archived: false },

  // ── PLANNED ──
  { id: 19, status: "planned",  title: "Day 1 Visit AI Coaching System",        category: "AI Systems",        priority: "high",   owner: "Christian + Ella",kpi: "Doctor performance score/visit", nextAction: "Define grading rubric",        blocker: "EHR integration needed",  notes: "AI listens to full Day 1 visit. 6-category grade. Report card + management summary.", archived: false },
  { id: 20, status: "planned",  title: "Corporate Marketing Nurture",           category: "Automations",       priority: "medium", owner: "Ella + Joanna",   kpi: "Rebook rate 6–12 months",      nextAction: "Confirm subaccount architecture", blocker: "Architecture TBD",       notes: "Stay top-of-mind with businesses post health talks. Decision-makers only.", archived: false },
  { id: 21, status: "planned",  title: "Medical Provider Referral Pipeline",    category: "Automations",       priority: "medium", owner: "Joanna + Ella",   kpi: "Provider database built",      nextAction: "Design referral form",          blocker: "",                        notes: "Referral page + form, provider database, ongoing nurture. Business card scan via GHL.", archived: false },
  { id: 22, status: "planned",  title: "SoftWave / Shockwave Therapy Launch",   category: "Revenue Systems",   priority: "high",   owner: "Joanna + Ella",   kpi: "Launch within 2 weeks of delivery", nextAction: "Prep landing page draft",   blocker: "Machine not yet delivered", notes: "Location-based scheduling. Campaigns to existing patients + community.", archived: false },
  { id: 23, status: "planned",  title: "Phone Call QA + AI Receptionist",       category: "AI Systems",        priority: "medium", owner: "Christian + Ella",kpi: "0 missed calls unanswered",    nextAction: "Define call grading criteria",   blocker: "",                        notes: "AI grades inbound calls, coaching reports. After-hours + missed call handling.", archived: false },
  { id: 24, status: "planned",  title: "Lloyd Table Resale Business",           category: "Revenue Systems",   priority: "low",    owner: "Joanna + Ella",   kpi: "Site live + leads captured",   nextAction: "GHL site wireframe",            blocker: "",                        notes: "Simple GHL-hosted site. Public used tables, private new tables.", archived: false },
  { id: 25, status: "planned",  title: "Functional Medicine / Lifestyle Reports", category: "Revenue Systems", priority: "low",    owner: "Christian + Ella",kpi: "First paying customer",        nextAction: "Map intake → report flow",       blocker: "Separate entity setup",   notes: "Telemedicine model. AI intake → lab eval → provider sign-off → report delivery.", archived: false },
  { id: 26, status: "planned",  title: "AI Meeting Assistant (Internal Ops)",   category: "AI Systems",        priority: "medium", owner: "Christian + Ella",kpi: "Action items auto-assigned",   nextAction: "Pilot on leadership meeting",    blocker: "",                        notes: "AI listens to leadership meetings. Extracts action items, owners, deadlines.", archived: false },
];

const STATUS_META = {
  active:  { label: "In Progress", color: "#C5A25D",  bg: "rgba(197,162,93,0.12)"  },
  done:    { label: "Done",        color: "#4caf7d",  bg: "rgba(76,175,125,0.12)"  },
  backlog: { label: "Backlog",     color: "#7a8fa6",  bg: "rgba(122,143,166,0.12)" },
  planned: { label: "Planned",     color: "#9b8bca",  bg: "rgba(155,139,202,0.12)" },
};

const PRIORITY_COLOR = { high: "#e05c5c", medium: GOLD, low: "#7a8fa6" };

const ELLA_EMAIL = "ella@bortolini.com";
const DR_DAVE_EMAIL = "dr.dave@staywelladjusted.com";
const PRIVILEGED = [ELLA_EMAIL, DR_DAVE_EMAIL];

// ── Helpers ───────────────────────────────────────────────────────────────────
function useLocalStorage(key, init) {
  const [val, setVal] = useState(() => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : init; }
    catch { return init; }
  });
  const set = (v) => { const next = typeof v === "function" ? v(val) : v; setVal(next); try { localStorage.setItem(key, JSON.stringify(next)); } catch {} };
  return [val, set];
}

function Badge({ status }) {
  const m = STATUS_META[status];
  return <span style={{ fontSize: 11, fontWeight: 600, padding: "2px 8px", borderRadius: 4, background: m.bg, color: m.color, letterSpacing: ".04em", textTransform: "uppercase" }}>{m.label}</span>;
}

function PriorityDot({ priority }) {
  return <span style={{ display: "inline-block", width: 7, height: 7, borderRadius: "50%", background: PRIORITY_COLOR[priority], marginRight: 6, flexShrink: 0 }} />;
}

// ── Request Card (inbox) ──────────────────────────────────────────────────────
function RequestCard({ req, onAccept, onDismiss, isPrivileged }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ background: "#1a2535", border: `1px solid ${GOLD}33`, borderRadius: 8, padding: "14px 16px", marginBottom: 10 }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
            <PriorityDot priority={req.priority} />
            <span style={{ fontWeight: 600, fontSize: 14, color: "#e8e0d0" }}>{req.title}</span>
          </div>
          <div style={{ fontSize: 12, color: "#7a8fa6" }}>
            From <span style={{ color: GOLD }}>{req.submittedBy}</span> · {req.category} · Requested by {req.deadline || "no deadline"}
          </div>
        </div>
        <button onClick={() => setOpen(o => !o)} style={{ background: "transparent", border: "none", color: "#7a8fa6", cursor: "pointer", fontSize: 18, lineHeight: 1, padding: 0 }}>{open ? "−" : "+"}</button>
      </div>
      {open && (
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid #2a3a4f" }}>
          <p style={{ fontSize: 13, color: "#b0bec5", marginBottom: 12, lineHeight: 1.6 }}>{req.description}</p>
          {isPrivileged && (
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => onAccept(req)} style={{ fontSize: 12, padding: "6px 14px", borderRadius: 5, background: `${GOLD}22`, border: `1px solid ${GOLD}66`, color: GOLD, cursor: "pointer", fontWeight: 600 }}>Add to Hub</button>
              <button onClick={() => onDismiss(req.id)} style={{ fontSize: 12, padding: "6px 14px", borderRadius: 5, background: "transparent", border: "1px solid #2a3a4f", color: "#7a8fa6", cursor: "pointer" }}>Dismiss</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Project Card ──────────────────────────────────────────────────────────────
function ProjectCard({ project, onEdit, onArchive, onStatusChange, isPrivileged, view }) {
  const [expanded, setExpanded] = useState(false);
  const m = STATUS_META[project.status];

  if (view === "kanban") {
    return (
      <div style={{ background: "#1a2535", border: "1px solid #2a3a4f", borderRadius: 8, padding: "12px 14px", marginBottom: 8, cursor: "pointer" }} onClick={() => setExpanded(o => !o)}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
          <PriorityDot priority={project.priority} />
          <span style={{ fontSize: 13, fontWeight: 600, color: "#e8e0d0", lineHeight: 1.3 }}>{project.title}</span>
        </div>
        <div style={{ fontSize: 11, color: "#7a8fa6" }}>{project.category} · {project.owner}</div>
        {expanded && (
          <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid #2a3a4f" }}>
            {project.notes && <p style={{ fontSize: 12, color: "#b0bec5", marginBottom: 8, lineHeight: 1.5 }}>{project.notes}</p>}
            {project.blocker && <div style={{ fontSize: 11, color: "#e05c5c", marginBottom: 6 }}>⚠ {project.blocker}</div>}
            {project.kpi && <div style={{ fontSize: 11, color: "#7a8fa6" }}>KPI: {project.kpi}</div>}
            {isPrivileged && (
              <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
                <button onClick={e => { e.stopPropagation(); onEdit(project); }} style={btnStyle}>Edit</button>
                <button onClick={e => { e.stopPropagation(); onArchive(project.id); }} style={btnStyle}>{project.archived ? "Unarchive" : "Archive"}</button>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ background: "#1a2535", border: "1px solid #2a3a4f", borderRadius: 8, padding: "14px 16px", marginBottom: 8 }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" }}>
            <PriorityDot priority={project.priority} />
            <span style={{ fontWeight: 600, fontSize: 14, color: "#e8e0d0" }}>{project.title}</span>
            <Badge status={project.status} />
          </div>
          <div style={{ fontSize: 12, color: "#7a8fa6" }}>{project.category} · Owner: {project.owner}</div>
        </div>
        <button onClick={() => setExpanded(o => !o)} style={{ background: "transparent", border: "none", color: "#7a8fa6", cursor: "pointer", fontSize: 18, lineHeight: 1, padding: 0, flexShrink: 0 }}>{expanded ? "−" : "+"}</button>
      </div>
      {expanded && (
        <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid #2a3a4f" }}>
          {project.notes && <p style={{ fontSize: 13, color: "#b0bec5", marginBottom: 10, lineHeight: 1.6 }}>{project.notes}</p>}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
            {project.kpi && <div><div style={{ fontSize: 10, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 2 }}>KPI</div><div style={{ fontSize: 12, color: "#c5cdd6" }}>{project.kpi}</div></div>}
            {project.nextAction && <div><div style={{ fontSize: 10, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 2 }}>Next Action</div><div style={{ fontSize: 12, color: "#c5cdd6" }}>{project.nextAction}</div></div>}
          </div>
          {project.blocker && <div style={{ fontSize: 12, color: "#e05c5c", padding: "6px 10px", background: "rgba(224,92,92,0.08)", borderRadius: 4, marginBottom: 10 }}>⚠ Blocker: {project.blocker}</div>}
          {isPrivileged && (
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <select value={project.status} onChange={e => onStatusChange(project.id, e.target.value)} style={selectStyle}>
                {Object.entries(STATUS_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
              <button onClick={() => onEdit(project)} style={btnStyle}>Edit</button>
              <button onClick={() => onArchive(project.id)} style={btnStyle}>{project.archived ? "Unarchive" : "Archive"}</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

const btnStyle = { fontSize: 12, padding: "5px 12px", borderRadius: 5, background: "rgba(197,162,93,0.1)", border: `1px solid ${GOLD}44`, color: GOLD, cursor: "pointer", fontWeight: 500 };
const selectStyle = { fontSize: 12, padding: "5px 10px", borderRadius: 5, background: "#0f1b28", border: "1px solid #2a3a4f", color: "#c5cdd6", cursor: "pointer" };
const inputStyle = { width: "100%", padding: "8px 12px", borderRadius: 6, background: "#0f1b28", border: "1px solid #2a3a4f", color: "#e8e0d0", fontSize: 13, marginBottom: 10, boxSizing: "border-box" };
const textareaStyle = { ...inputStyle, minHeight: 80, resize: "vertical", fontFamily: "inherit" };

// ── Edit Modal ────────────────────────────────────────────────────────────────
function EditModal({ project, onSave, onClose }) {
  const [form, setForm] = useState({ ...project });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 20 }}>
      <div style={{ background: "#1a2535", border: `1px solid ${GOLD}44`, borderRadius: 12, padding: 24, width: "100%", maxWidth: 560, maxHeight: "90vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <span style={{ fontWeight: 700, fontSize: 16, color: GOLD }}>Edit Project</span>
          <button onClick={onClose} style={{ background: "transparent", border: "none", color: "#7a8fa6", cursor: "pointer", fontSize: 22, lineHeight: 1 }}>×</button>
        </div>
        {[["title","Title"],["category","Category"],["owner","Owner"],["kpi","KPI"],["nextAction","Next Action"],["blocker","Blocker"]].map(([k, label]) => (
          <div key={k}>
            <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>{label}</label>
            <input value={form[k] || ""} onChange={e => set(k, e.target.value)} style={inputStyle} />
          </div>
        ))}
        <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>Notes</label>
        <textarea value={form.notes || ""} onChange={e => set("notes", e.target.value)} style={textareaStyle} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
          <div>
            <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>Status</label>
            <select value={form.status} onChange={e => set("status", e.target.value)} style={{ ...selectStyle, width: "100%", marginBottom: 0 }}>
              {Object.entries(STATUS_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>Priority</label>
            <select value={form.priority} onChange={e => set("priority", e.target.value)} style={{ ...selectStyle, width: "100%", marginBottom: 0 }}>
              {["high","medium","low"].map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 6 }}>
          <button onClick={onClose} style={{ ...btnStyle, background: "transparent", color: "#7a8fa6", border: "1px solid #2a3a4f" }}>Cancel</button>
          <button onClick={() => { onSave(form); onClose(); }} style={{ ...btnStyle, background: GOLD, color: NAVY, border: "none", fontWeight: 700 }}>Save</button>
        </div>
      </div>
    </div>
  );
}

// ── Add Project Modal ─────────────────────────────────────────────────────────
function AddModal({ onSave, onClose, prefill }) {
  const blank = { title: "", category: "Automations", owner: "Ella", status: "backlog", priority: "medium", kpi: "", nextAction: "", blocker: "", notes: "", archived: false };
  const [form, setForm] = useState(prefill ? { ...blank, ...prefill } : blank);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 20 }}>
      <div style={{ background: "#1a2535", border: `1px solid ${GOLD}44`, borderRadius: 12, padding: 24, width: "100%", maxWidth: 560, maxHeight: "90vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <span style={{ fontWeight: 700, fontSize: 16, color: GOLD }}>Add Project</span>
          <button onClick={onClose} style={{ background: "transparent", border: "none", color: "#7a8fa6", cursor: "pointer", fontSize: 22, lineHeight: 1 }}>×</button>
        </div>
        {[["title","Title"],["category","Category"],["owner","Owner"],["kpi","KPI"],["nextAction","Next Action"],["blocker","Blocker"]].map(([k, label]) => (
          <div key={k}>
            <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>{label}</label>
            <input value={form[k] || ""} onChange={e => set(k, e.target.value)} style={inputStyle} />
          </div>
        ))}
        <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>Notes</label>
        <textarea value={form.notes || ""} onChange={e => set("notes", e.target.value)} style={textareaStyle} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
          <div>
            <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>Status</label>
            <select value={form.status} onChange={e => set("status", e.target.value)} style={{ ...selectStyle, width: "100%", marginBottom: 0 }}>
              {Object.entries(STATUS_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", display: "block", marginBottom: 4 }}>Priority</label>
            <select value={form.priority} onChange={e => set("priority", e.target.value)} style={{ ...selectStyle, width: "100%", marginBottom: 0 }}>
              {["high","medium","low"].map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
        </div>
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 6 }}>
          <button onClick={onClose} style={{ ...btnStyle, background: "transparent", color: "#7a8fa6", border: "1px solid #2a3a4f" }}>Cancel</button>
          <button onClick={() => { onSave(form); onClose(); }} style={{ ...btnStyle, background: GOLD, color: NAVY, border: "none", fontWeight: 700 }}>Add Project</button>
        </div>
      </div>
    </div>
  );
}

// ── Login Screen ──────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState("");
  return (
    <div style={{ minHeight: "100vh", background: NAVY, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Jost', sans-serif" }}>
      <div style={{ width: 360, padding: 40, background: "#1a2535", borderRadius: 14, border: `1px solid ${GOLD}33`, textAlign: "center" }}>
        <div style={{ width: 56, height: 56, borderRadius: "50%", background: `${GOLD}22`, border: `1px solid ${GOLD}55`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: 22 }}>⬡</div>
        <h1 style={{ color: GOLD, fontFamily: "'Cormorant Garamond', serif", fontSize: 26, marginBottom: 4, fontWeight: 700 }}>WAC Project Hub</h1>
        <p style={{ color: "#7a8fa6", fontSize: 13, marginBottom: 28 }}>Well Adjusted Chiropractic</p>
        <input value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === "Enter" && onLogin(email)} placeholder="Enter your email" style={{ ...inputStyle, textAlign: "center" }} />
        <button onClick={() => onLogin(email)} style={{ width: "100%", padding: "10px", borderRadius: 8, background: GOLD, border: "none", color: NAVY, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "'Jost', sans-serif" }}>Enter Hub</button>
      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [userEmail, setUserEmail] = useLocalStorage("wac_email", null);
  const [projects, setProjects] = useLocalStorage("wac_projects", INITIAL_PROJECTS);
  const [requests, setRequests] = useLocalStorage("wac_requests", []);
  const [tab, setTab] = useState("projects");
  const [view, setView] = useState("list");
  const [catFilter, setCatFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showArchived, setShowArchived] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [addingProject, setAddingProject] = useState(null);
  const [webhookUrl, setWebhookUrl] = useLocalStorage("wac_webhook", "");
  const [showWebhookEdit, setShowWebhookEdit] = useState(false);

  // Poll for new requests via webhook URL (stored in localStorage)
  // In production, Apps Script POSTs to a Netlify function or directly updates localStorage via shared key
  // For now: requests can be added via the webhook endpoint set in settings

  const isPrivileged = PRIVILEGED.includes(userEmail);

  if (!userEmail) return <LoginScreen onLogin={e => { if (e.trim()) setUserEmail(e.trim().toLowerCase()); }} />;

  const handleEdit = (project) => setEditingProject(project);
  const handleSaveEdit = (updated) => setProjects(ps => ps.map(p => p.id === updated.id ? updated : p));
  const handleArchive = (id) => setProjects(ps => ps.map(p => p.id === id ? { ...p, archived: !p.archived } : p));
  const handleStatusChange = (id, status) => setProjects(ps => ps.map(p => p.id === id ? { ...p, status } : p));
  const handleAdd = (form) => {
    const id = Math.max(...projects.map(p => p.id), 0) + 1;
    setProjects(ps => [...ps, { ...form, id }]);
  };
  const handleAcceptRequest = (req) => {
    setAddingProject({ title: req.title, notes: req.description, category: req.category, priority: req.priority, owner: "Ella" });
    setRequests(rs => rs.filter(r => r.id !== req.id));
    setTab("projects");
  };
  const handleDismissRequest = (id) => setRequests(rs => rs.filter(r => r.id !== id));

  // Filter projects
  const visible = projects.filter(p => {
    if (p.archived && !showArchived) return false;
    if (catFilter !== "All" && p.category !== catFilter) return false;
    if (statusFilter !== "all" && p.status !== statusFilter) return false;
    return true;
  });

  // Stats
  const stats = { active: projects.filter(p => p.status === "active" && !p.archived).length, done: projects.filter(p => p.status === "done").length, backlog: projects.filter(p => p.status === "backlog").length, planned: projects.filter(p => p.status === "planned").length };
  const pendingRequests = requests.length;

  const tabStyle = (t) => ({
    padding: "8px 18px", borderRadius: 6, cursor: "pointer", fontSize: 13, fontWeight: 600, border: "none",
    background: tab === t ? `${GOLD}22` : "transparent",
    color: tab === t ? GOLD : "#7a8fa6",
    borderBottom: tab === t ? `2px solid ${GOLD}` : "2px solid transparent",
    transition: "all .15s",
  });

  return (
    <div style={{ minHeight: "100vh", background: NAVY, fontFamily: "'Jost', sans-serif", color: "#e8e0d0" }}>
      <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet" />

      {/* Header */}
      <div style={{ borderBottom: `1px solid ${GOLD}22`, padding: "0 28px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 58 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ color: GOLD, fontFamily: "'Cormorant Garamond', serif", fontSize: 20, fontWeight: 700, letterSpacing: ".02em" }}>WAC</span>
          <span style={{ color: "#2a3a4f", fontSize: 14 }}>|</span>
          <span style={{ color: "#7a8fa6", fontSize: 13 }}>Project Hub</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          {[["projects","Projects"],["requests",`Requests${pendingRequests ? ` (${pendingRequests})` : ""}`]].map(([t, label]) => (
            <button key={t} onClick={() => setTab(t)} style={tabStyle(t)}>{label}</button>
          ))}
          {isPrivileged && <button onClick={() => setTab("settings")} style={tabStyle("settings")}>Settings</button>}
          <button onClick={() => setUserEmail(null)} style={{ marginLeft: 8, fontSize: 12, padding: "5px 10px", borderRadius: 5, background: "transparent", border: "1px solid #2a3a4f", color: "#7a8fa6", cursor: "pointer" }}>Sign out</button>
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 24px" }}>

        {/* ── Projects Tab ── */}
        {tab === "projects" && (
          <>
            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 28 }}>
              {[["In Progress", stats.active, "#C5A25D"], ["Done", stats.done, "#4caf7d"], ["Backlog", stats.backlog, "#7a8fa6"], ["Planned", stats.planned, "#9b8bca"]].map(([label, count, color]) => (
                <div key={label} style={{ background: "#1a2535", borderRadius: 8, padding: "16px 18px", border: "1px solid #2a3a4f" }}>
                  <div style={{ fontSize: 28, fontWeight: 700, color, fontFamily: "'Cormorant Garamond', serif" }}>{count}</div>
                  <div style={{ fontSize: 11, color: "#7a8fa6", textTransform: "uppercase", letterSpacing: ".06em", marginTop: 2 }}>{label}</div>
                </div>
              ))}
            </div>

            {/* Controls */}
            <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap", alignItems: "center" }}>
              <select value={catFilter} onChange={e => setCatFilter(e.target.value)} style={selectStyle}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={selectStyle}>
                <option value="all">All Statuses</option>
                {Object.entries(STATUS_META).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
              <button onClick={() => setView(v => v === "list" ? "kanban" : "list")} style={btnStyle}>{view === "list" ? "Kanban View" : "List View"}</button>
              <button onClick={() => setShowArchived(s => !s)} style={{ ...btnStyle, color: showArchived ? "#e05c5c" : "#7a8fa6", borderColor: showArchived ? "#e05c5c44" : "#2a3a4f" }}>{showArchived ? "Hide Archived" : "Show Archived"}</button>
              {isPrivileged && <button onClick={() => setAddingProject({})} style={{ ...btnStyle, marginLeft: "auto", background: GOLD, color: NAVY, border: "none", fontWeight: 700 }}>+ Add Project</button>}
            </div>

            {/* List View */}
            {view === "list" && visible.map(p => (
              <ProjectCard key={p.id} project={p} onEdit={handleEdit} onArchive={handleArchive} onStatusChange={handleStatusChange} isPrivileged={isPrivileged} view="list" />
            ))}

            {/* Kanban View */}
            {view === "kanban" && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
                {Object.entries(STATUS_META).map(([status, meta]) => (
                  <div key={status}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: meta.color, textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 10, padding: "0 2px" }}>{meta.label} · {visible.filter(p => p.status === status).length}</div>
                    {visible.filter(p => p.status === status).map(p => (
                      <ProjectCard key={p.id} project={p} onEdit={handleEdit} onArchive={handleArchive} onStatusChange={handleStatusChange} isPrivileged={isPrivileged} view="kanban" />
                    ))}
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* ── Requests Tab ── */}
        {tab === "requests" && (
          <>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
              <div>
                <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, color: GOLD, marginBottom: 4 }}>Task Requests</h2>
                <p style={{ fontSize: 13, color: "#7a8fa6" }}>Submitted by your team via the request form. Accept to add directly to the hub.</p>
              </div>
              <a href="/task-request.html" target="_blank" style={{ ...btnStyle, textDecoration: "none", display: "inline-block" }}>Share Request Form ↗</a>
            </div>

            {requests.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 0", color: "#7a8fa6" }}>
                <div style={{ fontSize: 32, marginBottom: 12, opacity: .4 }}>📭</div>
                <div style={{ fontSize: 14 }}>No pending requests.</div>
                <div style={{ fontSize: 12, marginTop: 6 }}>Share the request form link with your team.</div>
              </div>
            ) : (
              requests.map(req => (
                <RequestCard key={req.id} req={req} onAccept={handleAcceptRequest} onDismiss={handleDismissRequest} isPrivileged={isPrivileged} />
              ))
            )}
          </>
        )}

        {/* ── Settings Tab ── */}
        {tab === "settings" && isPrivileged && (
          <div style={{ maxWidth: 560 }}>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 22, color: GOLD, marginBottom: 20 }}>Settings</h2>

            <div style={{ background: "#1a2535", border: "1px solid #2a3a4f", borderRadius: 10, padding: 20, marginBottom: 16 }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8, color: "#e8e0d0" }}>Webhook URL</div>
              <p style={{ fontSize: 12, color: "#7a8fa6", marginBottom: 12, lineHeight: 1.6 }}>Paste the Netlify function URL here. Google Apps Script will POST new form submissions to this endpoint, which adds them to your Requests tab.</p>
              {showWebhookEdit ? (
                <>
                  <input value={webhookUrl} onChange={e => setWebhookUrl(e.target.value)} placeholder="https://projectsforella.vercel.app/api/requests" style={inputStyle} />
                  <button onClick={() => setShowWebhookEdit(false)} style={{ ...btnStyle, background: GOLD, color: NAVY, border: "none" }}>Save</button>
                </>
              ) : (
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <code style={{ fontSize: 12, color: "#7a8fa6", background: "#0f1b28", padding: "6px 10px", borderRadius: 5, flex: 1, wordBreak: "break-all" }}>{webhookUrl || "Not set"}</code>
                  <button onClick={() => setShowWebhookEdit(true)} style={btnStyle}>Edit</button>
                </div>
              )}
            </div>

            <div style={{ background: "#1a2535", border: "1px solid #2a3a4f", borderRadius: 10, padding: 20, marginBottom: 16 }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8, color: "#e8e0d0" }}>Reset Projects to Default</div>
              <p style={{ fontSize: 12, color: "#7a8fa6", marginBottom: 12 }}>Restores the 26 pre-loaded projects. Cannot be undone.</p>
              <button onClick={() => { if (confirm("Reset all projects to default?")) setProjects(INITIAL_PROJECTS); }} style={{ ...btnStyle, color: "#e05c5c", borderColor: "#e05c5c44" }}>Reset Projects</button>
            </div>

            <div style={{ background: "#1a2535", border: "1px solid #2a3a4f", borderRadius: 10, padding: 20 }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 8, color: "#e8e0d0" }}>Signed in as</div>
              <div style={{ fontSize: 13, color: "#7a8fa6" }}>{userEmail}</div>
              <div style={{ fontSize: 12, color: "#4caf7d", marginTop: 4 }}>✓ Full access</div>
            </div>
          </div>
        )}
      </div>

      {editingProject && <EditModal project={editingProject} onSave={handleSaveEdit} onClose={() => setEditingProject(null)} />}
      {addingProject !== null && <AddModal onSave={handleAdd} onClose={() => setAddingProject(null)} prefill={addingProject} />}
    </div>
  );
}
