/**
 * api/requests.js — Vercel Serverless Function
 * Receives POST from Google Apps Script, stores request in Vercel KV
 * (or falls back to a simple in-memory log if KV is not configured).
 *
 * SETUP:
 *   1. In Vercel dashboard → your project → Storage → Create KV Store
 *   2. Link it to your project (adds KV_REST_API_URL + KV_REST_API_TOKEN env vars)
 *   3. The hub's Settings tab will poll GET /api/requests to load pending requests
 *
 * The hub calls:
 *   GET  /api/requests        → returns array of pending requests
 *   POST /api/requests        → adds a new request (called by Apps Script)
 *   DELETE /api/requests/:id  → removes a request (called when accepted/dismissed)
 */

export const config = { runtime: "edge" };

const KV_URL   = process.env.KV_REST_API_URL;
const KV_TOKEN = process.env.KV_REST_API_TOKEN;
const KV_KEY   = "wac_requests";

async function kvGet() {
  if (!KV_URL) return [];
  const res = await fetch(`${KV_URL}/get/${KV_KEY}`, {
    headers: { Authorization: `Bearer ${KV_TOKEN}` },
  });
  const data = await res.json();
  return data.result ? JSON.parse(data.result) : [];
}

async function kvSet(value) {
  if (!KV_URL) return;
  await fetch(`${KV_URL}/set/${KV_KEY}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${KV_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify({ value: JSON.stringify(value) }),
  });
}

export default async function handler(req) {
  const url = new URL(req.url);
  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  };

  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  // GET — return all pending requests
  if (req.method === "GET") {
    const requests = await kvGet();
    return new Response(JSON.stringify(requests), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // POST — add a new request (from Apps Script)
  if (req.method === "POST") {
    try {
      const body = await req.json();
      const requests = await kvGet();
      requests.push({ ...body, id: body.id || Date.now() });
      await kvSet(requests);
      return new Response(JSON.stringify({ ok: true }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } catch (err) {
      return new Response(JSON.stringify({ error: err.message }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  // DELETE — remove by id (/api/requests?id=123)
  if (req.method === "DELETE") {
    const id = Number(url.searchParams.get("id"));
    const requests = await kvGet();
    await kvSet(requests.filter(r => r.id !== id));
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response("Method not allowed", { status: 405, headers: corsHeaders });
}
